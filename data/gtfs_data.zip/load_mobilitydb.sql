------------------------------------------------------------------------------
-- Transform the GTFS data loaded by load_gtfs.sql into MobilityDB trips.
-- Run after load_gtfs.sql, e.g.
--   psql -d gtfs -f load_mobilitydb.sql
-- Each trip is built once, as a template, with the origins of its service days;
-- the table trips_mdb holds its occurrence on every service day.
------------------------------------------------------------------------------

-- Dates at which each service is provided: the days of its weekly pattern,
-- plus the dates added and minus the dates removed by calendar_dates.txt
DROP TABLE IF EXISTS service_dates;
CREATE TABLE service_dates AS
WITH b AS (
  SELECT c.service_id, setUnion(d::date) AS dates
  FROM calendar c,
    generate_series(c.start_date, c.end_date, interval '1 day') AS d
  WHERE (ARRAY[c.monday, c.tuesday, c.wednesday, c.thursday, c.friday,
    c.saturday, c.sunday])[extract(isodow FROM d)] = 1
  GROUP BY c.service_id ),
a AS (
  SELECT service_id, setUnion(date) AS dates FROM calendar_dates
  WHERE exception_type = 1 GROUP BY service_id ),
x AS (
  SELECT service_id, setUnion(date) AS dates FROM calendar_dates
  WHERE exception_type = 2 GROUP BY service_id ),
ba AS (
  SELECT service_id,
    CASE WHEN b.dates IS NULL THEN a.dates WHEN a.dates IS NULL THEN b.dates
      ELSE b.dates + a.dates END AS dates
  FROM b FULL JOIN a USING (service_id) )
SELECT service_id,
  CASE WHEN x.dates IS NULL THEN ba.dates ELSE ba.dates - x.dates END AS dates
FROM ba LEFT JOIN x USING (service_id);
DELETE FROM service_dates WHERE dates IS NULL;

-- The origins of the service days: the stop times of a service day are
-- measured from noon minus twelve hours in the time zone of the agency
ALTER TABLE service_dates ADD COLUMN origins tstzset;
UPDATE service_dates
SET origins = origins(dates, (SELECT agency_timezone FROM agency LIMIT 1));

-- Stops for each trip
DROP TABLE IF EXISTS trip_stops;
CREATE TABLE trip_stops (
  trip_id text,
  stop_sequence integer,
  no_stops integer,
  route_id text,
  service_id text,
  shape_id text,
  stop_id text,
  arrival_time interval,
  perc float
);

INSERT INTO trip_stops (trip_id, stop_sequence, no_stops, route_id, service_id,
  shape_id, stop_id, arrival_time)
SELECT t.trip_id, stop_sequence, MAX(stop_sequence) OVER (PARTITION BY t.trip_id),
  route_id, service_id, shape_id, stop_id, arrival_time
FROM trips t JOIN stop_times s ON t.trip_id = s.trip_id;

UPDATE trip_stops t
SET perc = CASE
WHEN stop_sequence = 1 then 0.0
WHEN stop_sequence = no_stops then 1.0
ELSE ST_LineLocatePoint(g.shape_geom, s.stop_geom)
END
FROM shape_geoms g, stops s
WHERE t.shape_id = g.shape_id AND t.stop_id = s.stop_id;

-- Segments between two consecutive stops of a trip
DROP TABLE IF EXISTS trip_segs;
CREATE TABLE trip_segs (
  trip_id text,
  route_id text,
  service_id text,
  stop1_sequence integer,
  stop2_sequence integer,
  no_stops integer,
  shape_id text,
  stop1_arrival_time interval,
  stop2_arrival_time interval,
  perc1 float,
  perc2 float,
  seg_geom geometry,
  seg_length float,
  no_points integer,
  PRIMARY KEY (trip_id, stop1_sequence)
);

INSERT INTO trip_segs (trip_id, route_id, service_id, stop1_sequence, stop2_sequence,
  no_stops, shape_id, stop1_arrival_time, stop2_arrival_time, perc1, perc2)
WITH temp AS (
  SELECT trip_id, route_id, service_id, stop_sequence,
    LEAD(stop_sequence) OVER w AS stop_sequence2,
  MAX(stop_sequence) OVER (PARTITION BY trip_id),
  shape_id, arrival_time, LEAD(arrival_time) OVER w, perc, LEAD(perc) OVER w
  FROM trip_stops WINDOW w AS (PARTITION BY trip_id ORDER BY stop_sequence)
)
SELECT * FROM temp WHERE stop_sequence2 IS NOT null;

UPDATE trip_segs t
SET seg_geom = ST_LineSubstring(g.shape_geom, perc1, perc2)
FROM shape_geoms g
WHERE t.shape_id = g.shape_id;

UPDATE trip_segs
SET seg_length = ST_Length(seg_geom), no_points = ST_NumPoints(seg_geom);

-- All points composing the geometry of each segment, with their arrival time
DROP TABLE IF EXISTS trip_points;
CREATE TABLE trip_points (
  trip_id text,
  route_id text,
  service_id text,
  stop1_sequence integer,
  point_sequence integer,
  point_geom geometry,
  point_arrival_time interval,
  PRIMARY KEY (trip_id, stop1_sequence, point_sequence)
);

INSERT INTO trip_points (trip_id, route_id, service_id, stop1_sequence,
  point_sequence, point_geom, point_arrival_time)
WITH temp1 AS (
  SELECT trip_id, route_id, service_id, stop1_sequence, stop2_sequence,
    no_stops, stop1_arrival_time, stop2_arrival_time, seg_length,
    (dp).path[1] AS point_sequence, no_points, (dp).geom as point_geom
FROM trip_segs, ST_DumpPoints(seg_geom) AS dp
),
temp2 AS (
SELECT trip_id, route_id, service_id, stop1_sequence, stop1_arrival_time,
    stop2_arrival_time, seg_length, point_sequence, no_points, point_geom
FROM temp1
WHERE point_sequence <> no_points OR stop2_sequence = no_stops
),
temp3 AS (
SELECT trip_id, route_id, service_id, stop1_sequence, stop1_arrival_time,
    stop2_arrival_time, point_sequence, no_points, point_geom,
    ST_Length(ST_MakeLine(array_agg(point_geom) OVER w)) / seg_length AS perc
FROM temp2 WINDOW w AS (PARTITION BY trip_id, service_id, stop1_sequence
    ORDER BY point_sequence)
)
SELECT trip_id, route_id, service_id, stop1_sequence, point_sequence, point_geom,
CASE
WHEN point_sequence = 1 then stop1_arrival_time
WHEN point_sequence = no_points then stop2_arrival_time
ELSE stop1_arrival_time + ((stop2_arrival_time - stop1_arrival_time) * perc)
END AS point_arrival_time
FROM temp3;

-- Data in the format used for creating the MobilityDB trips: the points of
-- each trip timed from the origin of the first day of its service
DROP TABLE IF EXISTS trips_input;
CREATE TABLE trips_input (
  trip_id text,
  route_id text,
  service_id text,
  point_geom geometry,
  t timestamptz
);

INSERT INTO trips_input
SELECT trip_id, route_id, t.service_id, point_geom,
  startValue(s.origins) + point_arrival_time AS t
FROM trip_points t JOIN service_dates s ON t.service_id = s.service_id;

-- One template per trip, with the origins of all its service days
DROP TABLE IF EXISTS trip_templates;
CREATE TABLE trip_templates (
  trip_id text PRIMARY KEY,
  service_id text NOT NULL,
  route_id text NOT NULL,
  ref timestamptz NOT NULL,
  origins tstzset NOT NULL,
  trip tgeompoint
);

INSERT INTO trip_templates(trip_id, service_id, route_id, ref, origins, trip)
SELECT i.trip_id, i.service_id, i.route_id, startValue(s.origins), s.origins,
  tgeompointSeq(array_agg(tgeompoint(i.point_geom, i.t) ORDER BY i.t))
FROM trips_input i JOIN service_dates s ON i.service_id = s.service_id
GROUP BY i.trip_id, i.service_id, i.route_id, s.origins;

-- The MobilityDB trips: the occurrence of each template on every service day
DROP TABLE IF EXISTS trips_mdb;
CREATE TABLE trips_mdb (
  trip_id text NOT NULL,
  service_id text NOT NULL,
  route_id text NOT NULL,
  date date NOT NULL,
  trip tgeompoint,
  PRIMARY KEY (trip_id, date)
);

INSERT INTO trips_mdb(trip_id, service_id, route_id, date, trip)
SELECT t.trip_id, t.service_id, t.route_id, d,
  occurrence(t.trip, t.ref, o)
FROM trip_templates t JOIN service_dates s USING (service_id),
  unnest(s.dates) WITH ORDINALITY AS u(d, n),
  LATERAL (SELECT valueN(s.origins, n::int) AS o) AS v;
